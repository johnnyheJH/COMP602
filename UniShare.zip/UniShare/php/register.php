<?php
require_once('connect.php');

if(isset($_POST) & !empty($_POST)){
    $username = $_POST('username');
    $email = $_POST('email');
    $password = md5($_POST('password'));
    $confirm_psw = md5($_POST('confirm_psw'));
    if($password == $confirm_psw){
        $sql = "INSERT INTO 'unishare' (username, email, password) VALUES ('$username', '$email', '$password')";
        $result = mysqli_query($connection, $sql);
//        if($result){
//            
//        }
    }else{
        echo "Password doesn't match! ";
    }
}


?>


<!--

<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>UniShare</title>
   <link rel="stylesheet" type="text/css" href="css/signUpPagestyle.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
   <script type="text/javascript" src="scripts/passwordValidation.js"></script>
</head>
<body background="background.png">

   
     <div calss="container">
      
       
       
       <div class="logo-container">  
            <img src="img/Logo.png" alt="logo" class="logo">
       </div>
       
       <form method="POST">
       
           <div class="signup-container">
              <h5>Please fill in this form to create an account.</h5>
            <hr>

              <div>
              <i class="fa fa-user icon"></i>
              <input id="username" type="text" placeholder="Full Name" name="username" value="<?php if(isset($username) & !empty($username)){ echo $username} ?>" required >
              <div id="name_error" class="value_error"></div>
              </div>

              <div>
               <i class="fa fa-envelope icon" style="width: 8.8px"></i>
               <input id="email" type="email" placeholder="Enter Your Email" name="email" value="<?php if(isset($email) & !empty($email)){ echo $email} ?>" required>
               <div id="email_error" class="value_error"></div>
              </div>

               <div>
               <i class="fa fa-lock icon"></i>
               <input  id="psw" type="password" placeholder="Enter Password" name="password" required>
               </div>

               <div>
               <i class="fa fa-lock icon"></i>
               <input  id="psw_cofirm" type="password" placeholder="Confirm Password" name="confirm_psw" required>
               <div id="password_error" class="value_error"></div>
               </div>

               <input type="submit" value="Sign Up" class="button" name="signup">



               <p> You have an account already?</p>
               <span class="login-link"><a href="index.html">Login Page</a></span>
           </div>
       
       </form>
       
      
       
   </div>
   
</body>
</html>-->
