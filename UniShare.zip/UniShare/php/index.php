<?php
    if (isset($_POST['submit']))
    {
        $user = $_POST["username"];
       echo "Welcome " $user;

    }
?>